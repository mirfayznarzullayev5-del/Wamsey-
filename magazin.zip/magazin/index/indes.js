// ============ DATA ============
const CATEGORIES = [
  { name: 'Oyoq Kiyimlar', count: 24, img: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80' },
  { name: 'Futbolkalar', count: 36, img: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&q=80' },
  { name: 'Rubashkalar', count: 18, img: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600&q=80' },
  { name: 'Shimlar', count: 22, img: 'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=600&q=80' },
  { name: 'Kostyumlar', count: 12, img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=80' },
  { name: 'Pidjaklar', count: 15, img: 'https://images.unsplash.com/photo-1548533591-bbe2b996f00a?w=600&q=80' },
  { name: 'Kepkalar', count: 8, img: 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=600&q=80' },
  { name: 'Remenlar', count: 14, img: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&q=80' },
  { name: 'Paypoqlar', count: 20, img: 'https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?w=600&q=80' },
];

const BRANDS_DATA = {
  'Oyoq Kiyimlar': [
    { name: 'CABANI', desc: 'Premium Italian footwear' },
    { name: 'ETOR', desc: 'Classic comfort' },
    { name: 'RUBINACCI', desc: 'Luxury craftsmanship' },
    { name: 'BUFALO', desc: 'Stylish & durable' },
  ],
  'Futbolkalar': [
    { name: 'Neyir', desc: 'Modern casual' },
    { name: 'Ramons', desc: 'Premium cotton' },
    { name: 'MCL', desc: 'Urban street style' },
    { name: 'KONKO', desc: 'Athletic fashion' },
    { name: 'Rafanelli', desc: 'Italian luxury' },
  ],
  'Rubashkalar': [
    { name: 'GUARES', desc: 'Business premium' },
    { name: 'DANIELL BESSI', desc: 'Formal elegance' },
  ],
  'Shimlar': [
    { name: 'Milano Denso', desc: 'Italian cut' },
    { name: 'Climber', desc: 'Active lifestyle' },
    { name: 'Formenti', desc: 'Classic tailoring' },
    { name: 'Marco Zanetti', desc: 'Designer slim fit' },
  ],
};

const PRODUCTS = [
  { id: 1, name: 'Classic Oxford Qora', brand: 'CABANI', cat: 'Oyoq Kiyimlar', price: 980000, oldPrice: 1200000, rating: 4.8, img: 'https://www.wemsey.com.tr/uploads/product/small/WSY12TS12162-1.jpg?v=4.6', badge: 'Sale', desc: 'Premium Italian leather Oxford shoes, perfect for formal occasions.', sizes: ['39', '40', '41', '42', '43', '44'], colors: ['#1a1a1a', '#8B4513', '#4a3728'] },
  { id: 2, name: 'Slim Fit Ko\'ylak', brand: 'GUARES', cat: 'Rubashkalar', price: 450000, oldPrice: null, rating: 4.9, img: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600&q=80', badge: 'New', desc: 'Ultra premium slim fit dress shirt in Egyptian cotton.', sizes: ['S', 'M', 'L', 'XL', 'XXL', '3XL'], colors: ['#FFFFFF', '#87CEEB', '#1a1a1a'] },
  { id: 3, name: 'Wool Blend Kostyum', brand: 'Marco Zanetti', cat: 'Kostyumlar', price: 2800000, oldPrice: 3500000, rating: 5.0, img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&q=80', badge: 'Sale', desc: 'Italian wool blend two-piece suit for the modern gentleman.', sizes: ['48', '50', '52', '54'], colors: ['#1a1a1a', '#36454F', '#8B8080'] },
  { id: 4, name: 'Casual Premium Shim', brand: 'Milano Denso', cat: 'Shimlar', price: 620000, oldPrice: null, rating: 4.7, img: 'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=600&q=80', badge: null, desc: 'Comfortable yet stylish chino trousers for every day wear.', sizes: ['30', '32', '34', '36', '38'], colors: ['#C0A882', '#1a1a1a', '#4a4a4a'] },
  { id: 5, name: 'Premium Pidjak', brand: 'RUBINACCI', cat: 'Pidjaklar', price: 1650000, oldPrice: 2000000, rating: 4.9, img: 'https://images.unsplash.com/photo-1548533591-bbe2b996f00a?w=600&q=80', badge: 'Sale', desc: 'Neapolitan handcrafted blazer with finest details.', sizes: ['46', '48', '50', '52'], colors: ['#1a1a1a', '#36454F', '#5C4033'] },
  { id: 6, name: 'Urban Futbolka', brand: 'Ramons', cat: 'Futbolkalar', price: 280000, oldPrice: null, rating: 4.6, img: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&q=80', badge: 'New', desc: 'Premium 100% pima cotton tee with contemporary fit.', sizes: ['S', 'M', 'L', 'XL', 'XXL'], colors: ['#FFFFFF', '#1a1a1a', '#808080'] },
  { id: 7, name: 'Kepka Premium', brand: 'KONKO', cat: 'Kepkalar', price: 195000, oldPrice: null, rating: 4.5, img: 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=600&q=80', badge: null, desc: 'Structured premium cap, perfect for casual style.', sizes: ['S/M', 'L/XL'], colors: ['#1a1a1a', '#FFFFFF', '#D4AF37'] },
  { id: 8, name: 'Italian Leather Remen', brand: 'ETOR', cat: 'Remenlar', price: 320000, oldPrice: 400000, rating: 4.8, img: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&q=80', badge: 'Sale', desc: 'Full grain Italian leather belt with brass buckle.', sizes: ['85cm', '90cm', '95cm', '100cm', '105cm'], colors: ['#1a1a1a', '#8B4513'] },
];

const REVIEWS = [
  { text: 'WAMSEY dan olgan kostyumim ajoyib! Sifati va kesimi juda professional. Buxoroda bunday do\'kon yo\'q edi. Albatta yana xarid qilaman!', name: 'Jasur T.', city: 'Buxoro', rating: 5 },
  { text: 'Ramons futbolkalari haqiqatan ham premium sifat. Yuvgandan keyin ham shakli o\'zgarmaydi. Xizmat tez va professional. Rahmat WAMSEY!', name: 'Sardor M.', city: 'Samarqand', rating: 5 },
  { text: 'Milano Denso shimlarini olib kiyib ko\'rdim — juda zo\'r material. Qo\'l tekizishi va tikuv sifati ajoyib. Endi doim WAMSEY dan xarid qilaman.', name: 'Bobur K.', city: 'Buxoro', rating: 5 },
  { text: 'CABANI tuflilarini olib 6 oy bo\'ldi, hali yangiday. Sifatiga 100% qo\'shilaman. Narxi ham qulay. Xizmat tez va do\'stona!', name: 'Ulugbek N.', city: 'Qarshi', rating: 4 },
  { text: 'Pidjak va shim komplekti oldim. Dizayn va material yuqori darajada. WAMSEY da xarid qilish — bu tajriba, shunchaki narsa sotib olish emas!', name: 'Otabek R.', city: 'Buxoro', rating: 5 },
];

const IG_IMGS = [
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80',
  'https://images.unsplash.com/photo-1548533591-bbe2b996f00a?w=400&q=80',
  'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80',
  'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400&q=80',
  'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=400&q=80',
  'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&q=80',
  'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&q=80',
  'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=400&q=80',
];

const PROMOS = { WAMSEY20: 20, WAMSEY25: 25, WAMSEY30: 30 };

// ============ STATE ============
let cart = [];
let promoDiscount = 0;
let reviewIdx = 0;
let currentFilter = 'Hammasi';

// ============ LOADER ============
window.addEventListener('load', () => {
  setTimeout(() => {
    document.getElementById('loader').classList.add('hidden');
    initAll();
  }, 2500);
});

// ============ CURSOR ============
const cursor = document.getElementById('cursor');
const ring = document.getElementById('cursor-ring');
document.addEventListener('mousemove', e => {
  cursor.style.left = e.clientX + 'px';
  cursor.style.top = e.clientY + 'px';
  setTimeout(() => {
    ring.style.left = e.clientX + 'px';
    ring.style.top = e.clientY + 'px';
  }, 80);
});

// ============ NAVBAR SCROLL ============
window.addEventListener('scroll', () => {
  const nb = document.getElementById('navbar');
  nb.classList.toggle('scrolled', window.scrollY > 60);
});

// ============ REVEAL ============
function initReveal() {
  const els = document.querySelectorAll('.reveal');
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
  }, { threshold: 0.12 });
  els.forEach(el => obs.observe(el));
}

// ============ MOBILE NAV ============
function openMobileNav() { document.getElementById('mobile-nav').classList.add('open') }
function closeMobileNav() { document.getElementById('mobile-nav').classList.remove('open') }

// ============ CATEGORIES ============
function renderCategories() {
  const grid = document.getElementById('cat-grid');
  CATEGORIES.forEach((cat, i) => {
    grid.innerHTML += `
      <div class="cat-card reveal reveal-delay-${(i % 4) + 1}" onclick="filterByCategory('${cat.name}')">
        <img class="cat-card-img" src="${cat.img}" alt="${cat.name}" loading="lazy">
        <div class="cat-card-overlay">
          <div class="cat-card-num">0${i + 1}</div>
          <div class="cat-card-name">${cat.name}</div>
          <div class="cat-card-count">${cat.count} mahsulot</div>
        </div>
        <div class="cat-quick">Ko'rish ↗</div>
        <div class="cat-gold-line"></div>
      </div>`;
  });
}

function filterByCategory(cat) {
  document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
  setTimeout(() => {
    currentFilter = cat;
    renderProducts();
    document.querySelectorAll('.filter-btn').forEach(b => {
      b.classList.toggle('active', b.textContent === cat);
    });
  }, 600);
}

// ============ BRANDS ============
function renderBrands() {
  const tabs = document.getElementById('brands-tabs');
  const cont = document.getElementById('brands-container');
  const cats = Object.keys(BRANDS_DATA);
  cats.forEach((cat, i) => {
    tabs.innerHTML += `<button class="brand-tab ${i === 0 ? 'active' : ''}" onclick="showBrands('${cat}',this)">${cat}</button>`;
    const list = document.createElement('div');
    list.className = `brands-list ${i === 0 ? 'active' : ''}`;
    list.id = `brand-list-${i}`;
    BRANDS_DATA[cat].forEach(b => {
      list.innerHTML += `<div class="brand-card">
        <div class="brand-card-name">${b.name}</div>
        <div class="brand-card-cat">${b.desc}</div>
      </div>`;
    });
    cont.appendChild(list);
  });
}
function showBrands(cat, btn) {
  document.querySelectorAll('.brand-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const cats = Object.keys(BRANDS_DATA);
  const idx = cats.indexOf(cat);
  document.querySelectorAll('.brands-list').forEach((l, i) => {
    l.classList.toggle('active', i === idx);
  });
}

// ============ PRODUCTS ============
function renderFilterBar() {
  const bar = document.getElementById('filter-bar');
  const cats = ['Hammasi', ...CATEGORIES.map(c => c.name)];
  cats.forEach(c => {
    bar.innerHTML += `<button class="filter-btn ${c === 'Hammasi' ? 'active' : ''}" onclick="setFilter('${c}',this)">${c}</button>`;
  });
}
function setFilter(cat, btn) {
  currentFilter = cat;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderProducts();
}
function renderProducts() {
  const grid = document.getElementById('products-grid');
  const filtered = currentFilter === 'Hammasi' ? PRODUCTS : PRODUCTS.filter(p => p.cat === currentFilter);
  if (!filtered.length) {
    grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;color:var(--silver-dark);padding:3rem;font-size:0.8rem;letter-spacing:0.2em">Bu kategoriyada mahsulot yo'q</div>`;
    return;
  }
  grid.innerHTML = filtered.map(p => `
    <div class="product-card reveal">
      <div class="product-img-wrap">
        <img class="product-img" src="${p.img}" alt="${p.name}" loading="lazy">
        ${p.badge ? `<div class="product-badge ${p.badge === 'New' ? 'new' : ''}">${p.badge}</div>` : ''}
        <div class="product-actions">
          <button class="btn-detail" onclick="openDetail(${p.id})">Batafsil</button>
          <button class="btn-cart" onclick="addToCart(${p.id})">+ Savat</button>
        </div>
      </div>
      <div class="product-info">
        <div class="product-brand">${p.brand}</div>
        <div class="product-name">${p.name}</div>
        <div class="product-rating">
          <div class="stars">${'★'.repeat(Math.floor(p.rating))}${p.rating % 1 ? '☆' : ''}</div>
          <span class="rating-num">${p.rating}</span>
        </div>
        <div class="product-price">
          <span class="price-current">${formatPrice(p.price)}</span>
          ${p.oldPrice ? `<span class="price-old">${formatPrice(p.oldPrice)}</span>` : ''}
        </div>
      </div>
    </div>`).join('');
  initReveal();
}

// ============ PRODUCT DETAIL ============
function openDetail(id) {
  const p = PRODUCTS.find(x => x.id === id);
  if (!p) return;
  const modal = document.getElementById('detail-modal');
  document.getElementById('detail-content').innerHTML = `
    <button class="detail-close" onclick="closeDetail()">✕</button>
    <div class="detail-gallery">
      <img class="detail-main-img" src="${p.img}" alt="${p.name}">
    </div>
    <div class="detail-info">
      <div class="detail-brand">${p.brand}</div>
      <div class="detail-name">${p.name}</div>
      <div class="detail-price">${formatPrice(p.price)}</div>
      <div class="detail-desc">${p.desc}</div>
      <div class="detail-options">
        <label>O'lcham tanlang</label>
        <div class="size-btns">
          ${p.sizes.map((s, i) => `<button class="size-btn ${i === 0 ? 'active' : ''}" onclick="this.parentNode.querySelectorAll('button').forEach(b=>b.classList.remove('active'));this.classList.add('active')">${s}</button>`).join('')}
        </div>
      </div>
      <div class="detail-options" style="margin-top:1rem">
        <label>Rang tanlang</label>
        <div class="color-btns">
          ${p.colors.map((c, i) => `<button class="color-btn ${i === 0 ? 'active' : ''}" style="background:${c};border:1px solid rgba(255,255,255,0.2)" onclick="this.parentNode.querySelectorAll('button').forEach(b=>b.classList.remove('active'));this.classList.add('active')"></button>`).join('')}
        </div>
      </div>
      <div class="detail-options" style="margin-top:1rem">
        <label>Miqdor</label>
        <div class="qty-wrap">
          <button class="qty-btn" onclick="changeQty(-1)">−</button>
          <input class="qty-val" id="detail-qty" value="1" readonly>
          <button class="qty-btn" onclick="changeQty(1)">+</button>
        </div>
      </div>
      <div class="detail-btns">
        <button class="btn-primary" style="border:none;width:100%;text-align:center;cursor:none" onclick="addToCart(${p.id});closeDetail()">Savatga Qo'shish ↗</button>
        <a href="https://t.me/@wamsey_bot" target="_blank" class="btn-tg">✈ Telegram orqali Buyurtma</a>
        <a href="https://instagram.com/wamsey_buxara" target="_blank" class="btn-ig">📷 Instagram orqali Bog'lanish</a>
      </div>
    </div>`;
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeDetail() {
  document.getElementById('detail-modal').classList.remove('open');
  document.body.style.overflow = '';
}
function changeQty(d) {
  const inp = document.getElementById('detail-qty');
  let v = parseInt(inp.value) + d;
  if (v < 1) v = 1;
  if (v > 99) v = 99;
  inp.value = v;
}
document.getElementById('detail-modal').addEventListener('click', e => {
  if (e.target === document.getElementById('detail-modal')) closeDetail();
});

// ============ CART ============
function addToCart(id) {
  const p = PRODUCTS.find(x => x.id === id);
  if (!p) return;
  const ex = cart.find(x => x.id === id);
  if (ex) ex.qty++;
  else cart.push({ ...p, qty: 1 });
  updateCart();
  showNotif(p.name + ' savatga qo\'shildi!');
}
function removeFromCart(id) {
  cart = cart.filter(x => x.id !== id);
  updateCart();
}
function changeCartQty(id, d) {
  const item = cart.find(x => x.id === id);
  if (!item) return;
  item.qty += d;
  if (item.qty < 1) { removeFromCart(id); return; }
  updateCart();
}
function updateCart() {
  const count = cart.reduce((a, b) => a + b.qty, 0);
  document.getElementById('cart-count').textContent = count;
  renderCartItems();
  calcTotals();
}
function renderCartItems() {
  const list = document.getElementById('cart-items-list');
  if (!cart.length) {
    list.innerHTML = `<div class="empty-cart"><div class="empty-cart-icon">🛍</div><p>Savat bo'sh</p></div>`;
    return;
  }
  list.innerHTML = cart.map(item => `
    <div class="cart-item">
      <img class="cart-item-img" src="${item.img}" alt="${item.name}">
      <div class="cart-item-info">
        <div class="cart-item-brand">${item.brand}</div>
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-price">${formatPrice(item.price)}</div>
        <div class="cart-item-qty">
          <button class="ci-qty-btn" onclick="changeCartQty(${item.id},-1)">−</button>
          <span class="ci-qty">${item.qty}</span>
          <button class="ci-qty-btn" onclick="changeCartQty(${item.id},1)">+</button>
        </div>
      </div>
      <button class="cart-item-del" onclick="removeFromCart(${item.id})">✕</button>
    </div>`).join('');
}
function calcTotals() {
  const subtotal = cart.reduce((a, b) => a + b.price * b.qty, 0);
  const discount = Math.round(subtotal * promoDiscount / 100);
  const total = subtotal - discount;
  document.getElementById('subtotal-val').textContent = formatPrice(subtotal);
  document.getElementById('total-val').textContent = formatPrice(total);
  const drow = document.getElementById('discount-row');
  if (discount > 0) {
    drow.style.display = 'flex';
    document.getElementById('discount-val').textContent = '-' + formatPrice(discount);
  } else {
    drow.style.display = 'none';
  }
}
function openCart() {
  document.getElementById('cart-sidebar').classList.add('open');
  document.getElementById('overlay').classList.add('show');
  document.body.style.overflow = 'hidden';
}
function closeCart() {
  document.getElementById('cart-sidebar').classList.remove('open');
  document.getElementById('overlay').classList.remove('show');
  document.body.style.overflow = '';
}
document.getElementById('overlay').addEventListener('click', () => {
  closeCart();
});

// ============ PROMO ============
function applyPromo() {
  const code = document.getElementById('promo-input').value.trim().toUpperCase();
  const msg = document.getElementById('promo-msg');
  if (PROMOS[code]) {
    promoDiscount = PROMOS[code];
    msg.className = 'promo-msg success';
    msg.textContent = `✓ ${promoDiscount}% chegirma qo'llanildi!`;
    calcTotals();
  } else {
    msg.className = 'promo-msg error';
    msg.textContent = '✕ Noto\'g\'ri promo kod';
    promoDiscount = 0;
    calcTotals();
  }
}

// ============ CHECKOUT ============
function openCheckout() {
  if (!cart.length) { showNotif('Savat bo\'sh!'); return; }
  closeCart();
  document.getElementById('checkout-modal').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeCheckout() {
  document.getElementById('checkout-modal').classList.remove('open');
  document.body.style.overflow = '';
}
function sendOrder() {
  const name = document.getElementById('co-name').value.trim();
  const phone = document.getElementById('co-phone').value.trim();
  const address = document.getElementById('co-address').value.trim();
  const note = document.getElementById('co-note').value.trim();
  if (!name || !phone || !address) { showNotif('Barcha maydonlarni to\'ldiring!'); return; }
  const subtotal = cart.reduce((a, b) => a + b.price * b.qty, 0);
  const discount = Math.round(subtotal * promoDiscount / 100);
  const total = subtotal - discount;
  let msg = `🛍 WAMSEY BUYURTMA\n\n👤 Ism: ${name}\n📞 Tel: ${phone}\n📍 Manzil: ${address}\n`;
  if (note) msg += `💬 Izoh: ${note}\n`;
  msg += `\n📦 Mahsulotlar:\n`;
  cart.forEach(i => { msg += `• ${i.brand} ${i.name} x${i.qty} = ${formatPrice(i.price * i.qty)}\n`; });
  if (discount > 0) msg += `\n🎁 Chegirma: -${formatPrice(discount)}`;
  msg += `\n💰 Jami: ${formatPrice(total)}`;
  const tgUrl = `https://t.me/@wamsey_bot?text=${encodeURIComponent(msg)}`;
  window.open(tgUrl, '_blank');
  cart = [];
  promoDiscount = 0;
  updateCart();
  closeCheckout();
  showNotif('Buyurtma Telegram orqali yuborildi!');
}

// ============ REVIEWS ============
function renderReviews() {
  const track = document.getElementById('reviews-track');
  REVIEWS.forEach(r => {
    track.innerHTML += `
      <div class="review-card">
        <div class="review-stars">${'★'.repeat(r.rating)}</div>
        <div class="review-text">"${r.text}"</div>
        <div class="reviewer">
          <div class="reviewer-avatar">${r.name[0]}</div>
          <div>
            <div class="reviewer-name">${r.name}</div>
            <div class="reviewer-city">${r.city}</div>
          </div>
        </div>
      </div>`;
  });
}
function slideReviews(dir) {
  const track = document.getElementById('reviews-track');
  const cards = track.querySelectorAll('.review-card');
  const w = window.innerWidth;
  let visible = w < 768 ? 1 : w < 1024 ? 2 : 3;
  const max = cards.length - visible;
  reviewIdx = Math.max(0, Math.min(max, reviewIdx + dir));
  const pct = reviewIdx * (100 / visible);
  track.style.transform = `translateX(-${pct}%)`;
}

// ============ INSTAGRAM ============
function renderInstagram() {
  const grid = document.getElementById('ig-grid');
  IG_IMGS.forEach(src => {
    grid.innerHTML += `
      <div class="ig-item">
        <img src="${src}" alt="WAMSEY Instagram" loading="lazy">
        <div class="ig-overlay"><span class="ig-icon">📷</span></div>
      </div>`;
  });
}

// ============ NOTIFICATION ============
let notifTimer;
function showNotif(text) {
  const n = document.getElementById('notif');
  document.getElementById('notif-text').textContent = text;
  n.classList.add('show');
  clearTimeout(notifTimer);
  notifTimer = setTimeout(() => n.classList.remove('show'), 2800);
}

// ============ HELPERS ============
function formatPrice(p) {
  return p.toLocaleString('uz-UZ') + ' so\'m';
}

// ============ INIT ============
function initAll() {
  renderCategories();
  renderBrands();
  renderFilterBar();
  renderProducts();
  renderReviews();
  renderInstagram();
  initReveal();
  updateCart();
}

// Parallax subtle
window.addEventListener('scroll', () => {
  const hero = document.getElementById('hero');
  const visual = hero.querySelector('.hero-visual');
  const sc = window.scrollY;
  if (visual) visual.style.transform = `translateY(${sc * 0.3}px)`;
});


// async function sendOrder() {

//   const name = document.getElementById('co-name').value;
//   const phone = document.getElementById('co-phone').value;
//   const address = document.getElementById('co-address').value;

//   // ❗ BU YER MUHIM: mahsulotni oladigan joy bo‘lishi kerak
//   const product = document.getElementById('product-name')?.value || "Noma'lum mahsulot";
//   const size = document.getElementById('product-size')?.value || "Noma'lum";

//   const text =
// `🛍 WAMSEY BUYURTMA

// 👤 Ism: ${name}
// 📞 Telefon: ${phone}
// 📍 Manzil: ${address}

// 👕 Mahsulot: ${product}
// 📏 Razmer: ${size}`;

//   const BOT_TOKEN = "8764569815:AAETdYXacrrjuwIOTXbOxboGtrcXRDWfrXU";
//   const CHAT_ID = "7774183081";

//   await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
//     method: "POST",
//     headers: { "Content-Type": "application/json" },
//     body: JSON.stringify({
//       chat_id: CHAT_ID,
//       text: text
//     })
//   });

//   alert("Buyurtma yuborildi!");
// }


async function sendOrder() {

  const name = document.getElementById('co-name').value;
  const phone = document.getElementById('co-phone').value;
  const address = document.getElementById('co-address').value;
  const formlar = document.getElementById('co-note').value;

  let text = `🛍 WAMSEY BUYURTMA\n\n`;
  text += `👤 Ism: ${name}\n\n📞 Tel: ${phone}\n\n📍 Manzil: ${address}\n\n 🗣️  Qoshimcha: ${formlar} \n`;
  text +=`_______________________________\n\n`
  text += `📦 MAHSULOTLAR:\n`;

  cart.forEach(item => {
    text += `\n👕 ${item.brand} - ${item.name}\n`;
    text += `\n💰 Narx: ${item.price} so'm \n`;
    text += `\n📏 Razmer: ${item.size}\n`;
    text += `\n🔢 Soni: ${item.qty}\n `;
  });

  const total = cart.reduce((a, b) => a + b.price * b.qty, 0);
  text += `\n💰 JAMI: ${total} so'm`;

  const BOT_TOKEN = "8764569815:AAETdYXacrrjuwIOTXbOxboGtrcXRDWfrXU";
  const CHAT_ID = "7774183081";

  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: CHAT_ID,
      text: text
    })
  });

  alert("Buyurtma yuborildi!");
}



let msg = `🛍 WAMSEY BUYURTMA\n\n`;

cart.forEach(i => {
  msg += `• ${i.brand} ${i.name} x${i.qty} = ${formatPrice(i.price * i.qty)}\n`;
});

msg += `\n💰 SUBTOTAL: ${formatPrice(subtotal)}`;

if (discount > 0) {
  msg += `\n🎁 PROMO: -${formatPrice(discount)} (${promoDiscount}%)`;
}

msg += `\n💰 JAMI: ${formatPrice(total)}`;